#OpenMV坐标系
#（原点）--------X轴
#  |
#  |
#  |
#  |
#  |
#  Y
#  轴
# 颜色追踪时需要控制环境光线稳定，避免识别标志物的色彩阈值发生改变
from pyb import UART, LED
from machine import I2C
from vl53l1x import VL53L1X
import sensor, image,math
import ustruct
import time
blue_threshold  = (3, 17, -20, 25, -35, -10)#设置蓝色阈值

RED_threshold  = (18, 56, 103, 35, -57, 116)#设置红色阈值（改后）

red_threshold = (11, 100, 8, 102, 15, 127)#设置红色阈值

sensor.reset() #初始化摄像头
sensor.set_pixformat(sensor.RGB565) #图像格式为 RGB565
sensor.set_framesize(sensor.HQVGA) #HQVGA: 240x160  X与Y
sensor.set_hmirror(True)#水平方向翻转
sensor.set_vflip(True)#垂直方向翻转
sensor.skip_frames(n=2000) #在更改设置后，跳过n张照片，等待感光元件变稳定
sensor.set_auto_gain(True) #使用颜色识别时需要关闭自动自动增益
sensor.set_auto_whitebal(True)#使用颜色识别时需要关闭自动自动白平衡
clock = time.clock() #追踪帧率


uart = UART(1,115200)   #设置串口波特率，与stm32一致
uart.init(115200, bits=8, parity=None, stop=1 )

def find_max(blobs):    #定义寻找色块面积最大的函数
    max_size=0
    for blob in blobs:     #blobs是多个色块 blob是一个色块 for循环把所有的色块找一遍
        if blob.pixels() > max_size:
            max_blob = blob
            max_size = blob.pixels()  #色块像素数量
    return max_blob

def sending_data(color,cx,cy):
    global uart;
    data = ustruct.pack("<bbbbbb",
    0x2c,0x12,int(color),int(cx),int(cy),0x5b)

    uart.write(data);
    for i in data:
        print("data的内容是：    ",hex(i))

i2c = I2C(2)
distance = VL53L1X(i2c)

while(True):
    clock.tick()
    img = sensor.snapshot().lens_corr(strength = 1.8, zoom = 1.0)#从感光芯片获得一张图像并且进行畸变校正
    blobs = img.find_blobs([RED_threshold])
    print("range: mm ", distance.read())
    time.sleep_ms(50)

    if blobs:
        color_status = ord('R')
        dis = distance.read()
        max_b = find_max(blobs)
        cx=max_b[5]
        cy=max_b[6]
        cw=max_b[4]
        ch=max_b[8]
        img.draw_rectangle(max_b.rect(),color=(255,255,255)) # rect 图像上画矩形
        img.draw_cross(max_b[5], max_b[6]) # cx, cy 图像上画十字
        print("中心X坐标",max_b[5],"中心Y坐标",max_b[6],"识别颜色类型","红色")
        sending_data(dis,max_b[5],max_b[6])



    else:
        #color_status = ord('A')
        sending_data(0,0,0)
