#ifndef __USART2_H
#define __USART2_H
#include "sys.h"

#define START   0X11
void uart2_init(u32 bound);
void USART2_IRQHandler(void); 
void TIM3_IRQHandler(void);
void chetou(void);
void coordinate_transformation(uint8_t center_x_temp, uint8_t center_y_temp, uint8_t color_type_temp);
void Hcsr04();
#endif


