#include "servo.h"
#include "math.h"

float a1,a2,a3,a4;            //a1Ϊ�ײ�Բ̨�߶� ʣ������Ϊ������е�۳��� 
float j1,j2,j3,j4;            //�ĸ���̬��
float L,H,P;	              //L =a2*sin(j2) + a3*sin(j2 + j3);H = a2*cos(j2) + a3*cos(j2 + j3); PΪ�ײ�Բ�̰뾶R
float j_all;	              //j2,j3,j4֮��
float len,high;               //�ܳ���,�ܸ߶�
float Cosj3,Sinj3;            //�����洢cosj3,sinj3��ֵ
float Cosj2,Sinj2;
float K1,K2;
float X,Y,Z;  	              //���� ��X,Y,Z������
int i;
float n,m,q;

int h;

int b1,b2,b3,b4,b5,b6;

double pulse1;
double pulse2;
double pulse3;
double pulse4;


double angle_1,angle_2, angle_3, angle_4;

void servo_angle_calculate(float target_x, float target_y, float target_z)
{
    n = 0;
	m = 0;
	q = 0;
	              //Ŀ������꣨X��Y��Z��
	X = target_x;
	Y = target_y;
	Z = target_z;

	P = 5;        //�ײ�Բ�̰뾶
	a1 = 15; 	  //�ײ�Բ�̸߶ȣ��������10cm        
	a2 = 15;      //��е�۳���
	a3 = 11;
	a4 = 14;
	
	if (X == 0) 
	    j1=90;
	else 
	    j1 = atan((Y+P)/X)*(57.3);

	for(i=0;i<=180;i++)
	{	
		j_all = 3.1415927*i/180;

		len = sqrt((Y+P)*(Y+P)+X*X);
		high = Z;
			
		L = len	- a4*sin(j_all);
		H = high - a4*cos(j_all) - a1;
		
		Cosj3 = ((L*L)+(H*H)-((a2)*(a2))-((a3)*(a3)))/(2*(a2)*(a3));
		Sinj3 = (sqrt(1-(Cosj3)*(Cosj3)));
		
		j3 = atan((Sinj3)/(Cosj3))*(57.3);
		
		K2 = a3*sin(j3/57.3);
		K1 = a2+a3*cos(j3/57.3);
		
		Cosj2 = (K2*L+K1*H)/(K1*K1+K2*K2);
		Sinj2 = (sqrt(1-(Cosj2)*(Cosj2)));
		
		j2 = atan((Sinj2)/(Cosj2))*57.3;
		j4 = j_all*57.3- j2 - j3;
		
		if(j2>=0&&j3>=0&&j4>=-90&&j2<=180&&j3<=180&&j4<=90)
		{
			n=n+1;
		}
    } 
   
   
   	for(i=0;i<=180;i++)
	{
		j_all = 3.1415927*i/180;
		
		len = sqrt((Y+P)*(Y+P)+X*X);
		high = Z;

		L = len	- a4*sin(j_all);
		H = high - a4*cos(j_all) - a1;
		
		Cosj3 = ((L*L)+(H*H)-((a2)*(a2))-((a3)*(a3)))/(2*(a2)*(a3));
		Sinj3 = (sqrt(1-(Cosj3)*(Cosj3)));
		
		j3 = atan((Sinj3)/(Cosj3))*(57.3);
		
		K2 = a3*sin(j3/57.3);
		K1 = a2+a3*cos(j3/57.3);
		
		Cosj2 = (K2*L+K1*H)/(K1*K1+K2*K2);
		Sinj2 = (sqrt(1-(Cosj2)*(Cosj2)));
		
		j2 = atan((Sinj2)/(Cosj2))*57.3;
		j4 = j_all*57.3- j2 - j3;
		
	    if(j2>=0&&j3>=0&&j4>=-90&&j2<=180&&j3<=180&&j4<=90)
		{
			m=m+1;
			if(m==n/2||m==(n+1)/2)
			{	
				break;
			}
		}
    }
	

}


/**** ��̬�ǻ���***/
void translate_angle_to_pulse(void)
{
	angle_1=j1;
	angle_2=j2;
	angle_3=j3;
	angle_4=-j4;

	pulse1 =  1.667*angle_1+80;         //����1����ת�Ƕȣ���Χ  
	pulse2 =  2.111*(90 - angle_2)+80;  //2����ת�Ƕȣ���Χ   
	pulse3 =  2.111*(90 - angle_3)+80;  //3����ת�Ƕȣ���Χ   
	pulse4 = -2.111*(90 + angle_4)+460; //4����ת�Ƕȣ���Χ    
	
}

void servo_caizhai(double pulse_1,double pulse_2,double pulse_3,double pulse_4)//��ժ
{
	//1�Ŷ��
	if(pulse_1 <=265) 
	{ 
		 for(b1=265;b1>=pulse_1;b1--)
		{ 
			 pca_setpwm1(0,0,b1);
		      delay_ms(10);
		 }
	}
	else if(pulse_1 >265)
	{ 
		 for(b1=265;b1<=pulse_1;b1++)
		{
			 pca_setpwm1(0,0,b1);
		      delay_ms(10);
		 }
	 }
	
	 pca_setpwm1(3,0,430);
	 delay_ms(100);
	 pca_setpwm1(2,0,200);
	 delay_ms(1000);
	//2�Ŷ��
	 
	 if(pulse_2 <=265) 
	{ 
		 for(b2=265;b2>=pulse_2;b2--)
		{ 
			 pca_setpwm1(1,0,b2);
		      delay_ms(10);
		 }
	}
	else if(pulse_2 >265)
	{ 
		 for(b2=265;b2<=pulse_2;b2++)
		{
			 pca_setpwm1(1,0,b2);
		      delay_ms(10);
		 }
	 }
	
	 
	 //3�Ŷ��
		 if(pulse_3 <=265) 
	{ 
		 for(b3=265;b3>=pulse_3;b3--)
		{ 
			 pca_setpwm1(2,0,b3);
		     delay_ms(10);
		 }
	}
	else if(pulse_3 >265)
	{ 
		 for(b3=265;b3<=pulse_3;b3++)
		{
			 pca_setpwm1(2,0,b3);
		      delay_ms(10);
		 }
	 }
	 //4�Ŷ��
		 if(pulse_4 <=265) 
	{ 
		 for(b4=265;b4>=pulse_4;b4--)
		{ 
			 pca_setpwm1(3,0,b4);
		     delay_ms(10);
		 }
	}
	else if(pulse_4 >265)
	{ 
		 for(b4=265;b4<=pulse_4;b4++)
		{
			 pca_setpwm1(3,0,b4);
		     delay_ms(10);
		 }
	 }
	 //5�Ŷ��
	 pca_setpwm1(8,0,460); 
	
}

void servo_fangzhi(double pulse_1,double pulse_2,double pulse_3,double pulse_4)//����
{
	//1�Ŷ��
	if(pulse_1 <=265) 
	{ 
		 for(b1=265;b1>=pulse_1;b1--)
		{ 
			 pca_setpwm1(0,0,b1);
		      delay_ms(10);
		 }
	}
	else if(pulse_1 >265)
	{ 
		 for(b1=265;b1<=pulse_1;b1++)
		{
			 pca_setpwm1(0,0,b1);
		      delay_ms(10);
		 }
	 }
	//2�Ŷ��
	 
	 if(pulse_2 <=265) 
	{ 
		 for(b2=265;b2>=pulse_2;b2--)
		{ 
			 pca_setpwm1(1,0,b2);
		      delay_ms(10);
		 }
	}
	else if(pulse_2 >265)
	{ 
		 for(b2=265;b2<=pulse_2;b2++)
		{
			 pca_setpwm1(1,0,b2);
		      delay_ms(10);
		 }
	 }
	
	  //4�Ŷ��
		 if(pulse_4 <=265) 
	{ 
		 for(b4=265;b4>=pulse_4;b4--)
		{ 
			 pca_setpwm1(3,0,b4);
		      delay_ms(10);
		 }
	}
	else if(pulse_4 >265)
	{ 
		 for(b4=265;b4<=pulse_4;b4++)
		{
			 pca_setpwm1(3,0,b4);
		      delay_ms(10);
		 }
	 }
	 
	 //3�Ŷ��
		 if(pulse_3 <=265) 
	{ 
		 for(b3=265;b3>=pulse_3;b3--)
		{ 
			 pca_setpwm1(2,0,b3);
		      delay_ms(10);
		 }
	}
	else if(pulse_3 >265)
	{ 
		 for(b3=265;b3<=pulse_3;b3++)
		{
			 pca_setpwm1(2,0,b3);
		      delay_ms(10);
		 }
	 }
	
	 //5�Ŷ��
	 pca_setpwm1(8,0,80); 
	
}


void servo_qishi(double pulse_1,double pulse_2,double pulse_3,double pulse_4)//��ʼλ��
{
	//1�Ŷ��
	if(pulse_1 <=265) 
	{ 
		 for(b1=265;b1>=pulse_1;b1--)
		{ 
			 pca_setpwm1(0,0,b1);
		     delay_ms(10);
		 }
	}
	else if(pulse_1 >265)
	{ 
		 for(b1=265;b1<=pulse_1;b1++)
		{
			 pca_setpwm1(0,0,b1);
		      delay_ms(10);
		 }
	 }
	//2�Ŷ��
	 
	 if(pulse_2 <=265) 
	{ 
		 for(b2=265;b2>=pulse_2;b2--)
		{ 
			 pca_setpwm1(1,0,b2);
		     delay_ms(10);
		 }
	}
	else if(pulse_2 >265)
	{ 
		 for(b2=265;b2<=pulse_2;b2++)
		{
			 pca_setpwm1(1,0,b2);
		      delay_ms(10);
		 }
	 }
	
	 
	 //3�Ŷ��
		 if(pulse_3 <=265) 
	{ 
		 for(b3=265;b3>=pulse_3;b3--)
		{ 
			 pca_setpwm1(2,0,b3);
		      delay_ms(10);
		 }
	}
	else if(pulse_3 >265)
	{ 
		 for(b3=265;b3<=pulse_3;b3++)
		{
			 pca_setpwm1(2,0,b3);
		      delay_ms(10);
		 }
	 }
	 //4�Ŷ��
		 if(pulse_4 <=265) 
	{ 
		 for(b4=265;b4>=pulse_4;b4--)
		{ 
			 pca_setpwm1(3,0,b4);
		      delay_ms(10);
		 }
	}
	else if(pulse_4 >265)
	{ 
		 for(b4=265;b4<=pulse_4;b4++)
		{
			 pca_setpwm1(3,0,b4);
		      delay_ms(10);
		 }
	 }
	 //5�Ŷ��
	 pca_setpwm1(8,0,80); 
	
}



////1�Ŷ��0----180��
//void servo_1(void)
//{
//	for(h=102;h<=450;h++)
//		{  
//			 pca_setpwm1(0,0,h);
//       delay_ms(50);
//		}
//		for(h=450;h>=102;h--)
//		{  
//			 pca_setpwm1(0,0,h);
//       delay_ms(50);
//		}

//}
////2�Ŷ��0----90��	
//void servo_2(void)
//{
//	for(h=102;h<=270;h++)
//		{  
//			 pca_setpwm1(1,0,h);
//       delay_ms(50);
//		}
//		for(h=270;h>=102;h--)
//		{  
//			 pca_setpwm1(1,0,h);
//       delay_ms(50);
//		}

//}
////3�Ŷ��0-----90��
//void servo_3(void)
//{
//	for(h=140;h<=340;h++)
//		{  
//			 pca_setpwm1(2,0,h);
//       delay_ms(50);
//		}
//		for(h=340;h>=140;h--)
//		{  
//			 pca_setpwm1(2,0,h);
//       delay_ms(50);
//		}

//}
////4�Ŷ��0-----180��
//void servo_4(void)
//{
//	for(h=140;h<=350;h++)
//		{  
//			 pca_setpwm1(3,0,h);
//       delay_ms(50);
//		}
//		for(h=350;h>=140;h--)
//		{  
//			 pca_setpwm1(3,0,h);
//       delay_ms(50);
//		}

//}


////5�Ŷ�� 
//void servo_5 (void)
//{
//	for(h=102;h<=512;h++)
//		{  
//			 pca_setpwm1(4,0,h);
//       delay_ms(50);
//		}
//		for(h=512;h>=102;h--)
//		{  
//			 pca_setpwm1(4,0,h);
//       delay_ms(50);
//		}

//}
//	



////6�Ŷ��   �ſ�---�պ�
//void servo_6(void)
//{
//	for(h=150;h<=230;h++)
//		{  
//			 pca_setpwm1(5,0,h);
//       delay_ms(50);
//		}
//		for(h=230;h>=150;h--)
//		{  
//			 pca_setpwm1(5,0,h);
//       delay_ms(50);
//		}

//}
	
