#ifndef __SERVO_H
#define __SERVO_H	 
#include "sys.h"

void servo_angle_calculate(float target_x, float target_y, float target_z);
void servo_1(void);
void servo_2(void);
void servo_3(void);
void servo_4(void);
void servo_5(void);
void servo_6(void);
void translate_angle_to_pulse(void);
void servo_yuandian_blue(void);
void servo_yuandian_green(void);
void servo_yuandian_red(void);
void servo_caizhai(double pulse_1,double pulse_2,double pulse_3,double pulse_4);
void servo_fangzhi(double pulse_1,double pulse_2,double pulse_3,double pulse_4);
void servo_fangzhi_green(double pulse_1,double pulse_2,double pulse_3,double pulse_4);
void servo_fangzhi_red(double pulse_1,double pulse_2,double pulse_3,double pulse_4);
#endif
